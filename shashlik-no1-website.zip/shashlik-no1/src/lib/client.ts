import type { Procedures } from "@/api";
import { apiClient } from "@adaptive-ai/sdk/client";

export const client = apiClient<Procedures>();
