import { db } from "@/api/db";
import { env } from "@/lib/env";
import { seedDatabase } from "./seed";

export async function health() {
  return {
    status: "ok",
    timestamp: new Date().toISOString(),
    db: await db.$queryRaw`SELECT 1 as result`
      .then(() => "connected")
      .catch(() => "disconnected"),
    env: env.VITE_NODE_ENV,
  };
}

// Seed database with initial data
export async function seed() {
  await seedDatabase();
  return { success: true };
}

// Menu Items
export async function getMenuItems() {
  return await db.menuItem.findMany({
    orderBy: { category: "asc" }
  });
}

export async function getMenuItemsByCategory(category: string) {
  return await db.menuItem.findMany({
    where: { category },
    orderBy: { price: "asc" }
  });
}

// Bookings
export async function createBooking(input: {
  name: string;
  phone: string;
  email?: string;
  date: string;
  time: string;
  guests: number;
  comment?: string;
}) {
  return await db.booking.create({
    data: {
      ...input,
      status: "pending"
    }
  });
}

export async function getBookings() {
  return await db.booking.findMany({
    orderBy: { createdAt: "desc" }
  });
}

export async function updateBookingStatus(id: string, status: string) {
  return await db.booking.update({
    where: { id },
    data: { status }
  });
}

// Orders
export async function createOrder(input: {
  name: string;
  phone: string;
  email?: string;
  address?: string;
  pickupTime?: string;
  comment?: string;
  items: Array<{ menuItemId: string; quantity: number; price: number }>;
}) {
  const total = input.items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return await db.order.create({
    data: {
      name: input.name,
      phone: input.phone,
      email: input.email,
      address: input.address,
      pickupTime: input.pickupTime,
      comment: input.comment,
      total,
      status: "pending",
      items: {
        create: input.items.map(item => ({
          menuItemId: item.menuItemId,
          quantity: item.quantity,
          price: item.price
        }))
      }
    },
    include: {
      items: {
        include: {
          menuItem: true
        }
      }
    }
  });
}

export async function getOrders() {
  return await db.order.findMany({
    include: {
      items: {
        include: {
          menuItem: true
        }
      }
    },
    orderBy: { createdAt: "desc" }
  });
}

export async function updateOrderStatus(id: string, status: string) {
  return await db.order.update({
    where: { id },
    data: { status }
  });
}

// Reviews
export async function getReviews() {
  return await db.review.findMany({
    orderBy: { createdAt: "desc" },
    take: 10
  });
}

export async function createReview(input: {
  author: string;
  rating: number;
  text: string;
  date: string;
}) {
  return await db.review.create({
    data: input
  });
}
