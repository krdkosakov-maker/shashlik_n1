import type { Job } from "plainjob";

// Define all job handlers here
export const handlers = {
  debug: async (payload: { info: string }, job: Job) => {
    console.debug(`Debug handler info: ${payload.info}, job id: ${job.id}`);
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
} satisfies Record<string, (payload: any, job: Job) => Promise<void>>;
