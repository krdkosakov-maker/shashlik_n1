import Database from "better-sqlite3";
import { env } from "@/lib/env";

// We're hosting both development and production error logs in the same database file.
const errorsDb = new Database("errors.db", { fileMustExist: false });

// Disable WAL mode.
errorsDb.pragma("journal_mode = DELETE");

errorsDb.exec(`
  CREATE TABLE IF NOT EXISTS error_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    environment TEXT NOT NULL,
    source TEXT NOT NULL,
    message TEXT NOT NULL,
    stack TEXT,
    metadata TEXT,
    request_id TEXT,
    created_at INTEGER NOT NULL DEFAULT (unixepoch())
  )
`);

errorsDb.exec(`
  CREATE INDEX IF NOT EXISTS idx_error_logs_env_created 
  ON error_logs (environment, created_at)
`);

type LogEntry = {
  source: "server" | "client" | "worker";
  message: string;
  stack?: string;
  metadata?: object;
  requestId?: string;
};

const insertStmt = errorsDb.prepare(`
  INSERT INTO error_logs (environment, source, message, stack, metadata, request_id)
  VALUES (?, ?, ?, ?, ?, ?)
`);

export function logError(entry: LogEntry) {
  insertStmt.run(
    env.VITE_NODE_ENV,
    entry.source,
    entry.message,
    entry.stack ?? null,
    entry.metadata ? JSON.stringify(entry.metadata) : null,
    entry.requestId ?? null
  );
}

export function hasErrors(sinceMinutes = 5): boolean {
  const stmt = errorsDb.prepare(`
    SELECT COUNT(*) as count FROM error_logs 
    WHERE created_at > unixepoch() - ?
  `);
  const result = stmt.get(sinceMinutes * 60) as { count: number };
  return result.count > 0;
}

export function getRecentErrors(limit = 50) {
  const stmt = errorsDb.prepare(`
    SELECT * FROM error_logs 
    ORDER BY created_at DESC 
    LIMIT ?
  `);
  return stmt.all(limit);
}
