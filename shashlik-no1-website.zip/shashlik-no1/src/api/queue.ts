import Database from "better-sqlite3";
import { better, defineQueue, defineWorker, JobStatus, type Job } from "plainjob";
import { handlers } from "@/api/jobs";
import { logError } from "@/api/errors";
import { env } from "@/lib/env";

const queueDb = new Database(env.QUEUE_DB_FILE_NAME, { fileMustExist: false });
// Disable WAL mode.
queueDb.pragma("journal_mode = DELETE");

const queueDbConnection = better(queueDb);
const internalQueue = defineQueue({ connection: queueDbConnection });

// It logs every polling attempt, which can be very verbose.
const logger = {
  error: console.error.bind(console),
  warn: console.warn.bind(console),
  info: () => {},
  debug: () => {},
};

type JobData = {
  action: string;
  payload: unknown;
};

type Handlers = typeof handlers;

type Queue = {
  [K in keyof Handlers]: (payload: Parameters<Handlers[K]>[0]) => { id: number };
};

export const queue = new Proxy({} as Queue, {
  get(_, action: string) {
    return (payload: unknown) => {
      return internalQueue.add("default", { action, payload });
    };
  },
});

export function getJob(id: number) {
  return internalQueue.getJobById(id);
}

export function getActiveJobCount() {
  return internalQueue.countJobs({ status: JobStatus.Processing });
}

export function getPendingJobCount() {
  return internalQueue.countJobs({ status: JobStatus.Pending });
}

export function getJobCounts() {
  return {
    pending: internalQueue.countJobs({ status: JobStatus.Pending }),
    processing: internalQueue.countJobs({ status: JobStatus.Processing }),
    done: internalQueue.countJobs({ status: JobStatus.Done }),
    failed: internalQueue.countJobs({ status: JobStatus.Failed }),
  };
}

export function startWorker() {
  const worker = defineWorker(
    "default",
    async (job) => {
      const data = JSON.parse(job.data) as JobData;
      const { action, payload } = data;
      const handler = handlers[action as keyof Handlers];

      if (!handler) {
        console.error(`No handler registered for action: ${action}`);
        return;
      }

      console.log(`Processing job ${job.id} with action: ${action}`);
      await (handler as (payload: unknown, job: Job) => Promise<void>)(payload, job);
    },
    {
      queue: internalQueue,
      logger,
      onCompleted: (job) => {
        const data = JSON.parse(job.data) as JobData;
        console.log(`Job ${job.id} completed: ${data.action}`);
      },
      onFailed: (job, error: unknown) => {
        const data = JSON.parse(job.data) as JobData;
        logError({
          source: "worker",
          message: error instanceof Error ? error.message : String(error),
          stack: error instanceof Error ? error.stack : undefined,
          metadata: { jobId: job.id, action: data.action },
        });
        console.error(`Job ${job.id} failed: ${data.action}`, error);
      },
    },
  );

  void worker.start();
}
