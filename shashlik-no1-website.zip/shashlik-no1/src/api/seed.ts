import { db } from "./db";

const menuItems = [
  // ШАШЛЫК & ГРИЛЬ
  {
    name: "Свиная шея",
    category: "Шашлык & Гриль",
    price: 210,
    unit: "100г",
    description: "Сочная шея, обжаренная на гриле до золотистой корочки, в сочетании с луком и зеленью",
    image: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=500&q=80"
  },
  {
    name: "Свиная мякоть",
    category: "Шашлык & Гриль",
    price: 190,
    unit: "100г",
    description: "Свиная мякоть, обжаренная на гриле до золотистой корочки, в сочетании со свежим репчатым луком и зеленью",
    image: "https://images.unsplash.com/photo-1603360946369-dc9bb6258143?w=500&q=80"
  },
  {
    name: "Свиные рёбра",
    category: "Шашлык & Гриль",
    price: 180,
    unit: "100г",
    description: "Аппетитные рёбра, обжаренные на мангале до золотистой корочки, в сочетании со свежим репчатым луком и зеленью",
    image: "https://images.unsplash.com/photo-1544025162-d76694265947?w=500&q=80"
  },
  {
    name: "Антрекот свиной",
    category: "Шашлык & Гриль",
    price: 150,
    unit: "100г",
    description: "Свиной стейк, обжаренный на мангале до золотистой корочки, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1588168333986-5078d3ae3976?w=500&q=80"
  },
  {
    name: "Бараньи рёбра",
    category: "Шашлык & Гриль",
    price: 350,
    unit: "100г",
    description: "Ароматные рёбра, обжаренные на мангале до золотистой корочки, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=500&q=80"
  },
  {
    name: "Баранья мякоть",
    category: "Шашлык & Гриль",
    price: 400,
    unit: "100г",
    description: "Нежная мякоть, обжаренная на мангале до золотистой корочки, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1574484284002-952d92456975?w=500&q=80"
  },
  {
    name: "Бараньи пистолетики",
    category: "Шашлык & Гриль",
    price: 500,
    unit: "100г",
    description: "Каре ягнёнка, обжаренные на мангале до золотистой корочки, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1546833998-877b37c2e5c6?w=500&q=80"
  },
  {
    name: "Крылья",
    category: "Шашлык & Гриль",
    price: 120,
    unit: "100г",
    description: "Вкуснейшие куриные крылья, обжаренные на мангале до золотистой корочки, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1527477396000-e27163b481c2?w=500&q=80"
  },
  {
    name: "Куриная грудка",
    category: "Шашлык & Гриль",
    price: 130,
    unit: "100г",
    description: "Домашняя куриная грудка, обжаренная на мангале до золотистой корочки, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1598103442097-8b74394b95c6?w=500&q=80"
  },
  {
    name: "Куриное ассорти",
    category: "Шашлык & Гриль",
    price: 100,
    unit: "100г",
    description: "Домашние голень, бедро, спинка обжаренные на мангале до золотистой корочки, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1632778149955-e80f8ceca2e8?w=500&q=80"
  },
  {
    name: "Перепёлка",
    category: "Шашлык & Гриль",
    price: 500,
    unit: "шт",
    description: "Домашняя аппетитная перепёлка, обжаренная на мангале до золотистой корочки, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1598514982901-ae62764ae75e?w=500&q=80"
  },
  {
    name: "Говяжья печень в сетке",
    category: "Шашлык & Гриль",
    price: 150,
    unit: "100г",
    description: "Сочная печень в свиной сетке, обжаренная на мангале, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=500&q=80"
  },
  {
    name: "Говяжья вырезка",
    category: "Шашлык & Гриль",
    price: 400,
    unit: "100г",
    description: "Наисвежайшая вырезка, обжаренная на мангале с добавлением сливочного масла, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1558030006-450675393462?w=500&q=80"
  },
  {
    name: "Сёмга",
    category: "Шашлык & Гриль",
    price: 400,
    unit: "100г",
    description: "Нежная сёмга, обжаренная на мангале до золотистой корочки, в сочетании со свежей долькой лимона и с веточкой укропа",
    image: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=500&q=80"
  },
  
  // ЛЮЛЯ-КЕБАБ НА МАНГАЛЕ
  {
    name: "Люля из баранины",
    category: "Люля-Кебаб на мангале",
    price: 450,
    unit: "шт",
    description: "Сочное баранье люля, обжаренное на мангале, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=500&q=80"
  },
  {
    name: "Люля из говядины",
    category: "Люля-Кебаб на мангале",
    price: 400,
    unit: "шт",
    description: "Нежное свино-говяжье люля, обжаренное на мангале с добавлением сливочного масла, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1603360946369-dc9bb6258143?w=500&q=80"
  },
  {
    name: "Люля из курицы",
    category: "Люля-Кебаб на мангале",
    price: 350,
    unit: "шт",
    description: "Нежнейшее куриное люля, обжаренное на мангале с добавлением сливочного масла, в сочетании со свежим луком и зеленью",
    image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=500&q=80"
  },

  // ОВОЩИ & ГАРНИРЫ
  {
    name: "Картофель с салом",
    category: "Овощи & Гарниры",
    price: 250,
    unit: "шт",
    description: "Нежная картошка с домашним свиным салом, обжаренная на мангале до золотистой корочки",
    image: "https://images.unsplash.com/photo-1518013431117-eb1465fa5752?w=500&q=80"
  },
  {
    name: "Картофель фри",
    category: "Овощи & Гарниры",
    price: 200,
    unit: "100г",
    description: "Вкуснейший картофель фри, обжаренный во фритюре до золотистой корочки",
    image: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=500&q=80"
  },
  {
    name: "Овощи на мангале",
    category: "Овощи & Гарниры",
    price: 150,
    unit: "100г",
    description: "Нежный помидор, баклажан, перец, обжаренные на мангале",
    image: "https://images.unsplash.com/photo-1607894212099-80e07db5a6e1?w=500&q=80"
  },
  {
    name: "Грибы",
    category: "Овощи & Гарниры",
    price: 120,
    unit: "100г",
    description: "Сочные грибы, обжаренные на мангале с добавлением паприки",
    image: "https://images.unsplash.com/photo-1569418218959-e09eb5e72389?w=500&q=80"
  },
  {
    name: "Наггетсы",
    category: "Овощи & Гарниры",
    price: 400,
    unit: "5 шт",
    description: "Хрустящие наггетсы, обжаренные во фритюре до золотистой корочки",
    image: "https://images.unsplash.com/photo-1562967914-608f82629710?w=500&q=80"
  },

  // САЛАТЫ
  {
    name: "Овощной салат",
    category: "Салаты",
    price: 150,
    unit: "100г",
    description: "Салат со свежими овощами с добавками",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=500&q=80"
  },
  {
    name: "Сате",
    category: "Салаты",
    price: 150,
    unit: "100г",
    description: "Горячий салат, свежие овощи обжаренные на мангале, в последствии тушёные с добавлением сливочного масла, в сочетании с кинзой",
    image: "https://images.unsplash.com/photo-1546793665-c74683f339c1?w=500&q=80"
  },

  // ХЛЕБ & СОУСЫ
  {
    name: "Хлеб",
    category: "Хлеб & Соусы",
    price: 50,
    unit: "шт",
    description: "Бездрожжевая лепёшка из тандыра",
    image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=500&q=80"
  },
  {
    name: "Лаваш из тандыра",
    category: "Хлеб & Соусы",
    price: 100,
    unit: "2 шт",
    description: "Армянский бездрожжевой лаваш из тандыра",
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=500&q=80"
  },
  {
    name: "Белый соус",
    category: "Хлеб & Соусы",
    price: 150,
    unit: "шт",
    description: "Фирменный белый соус с добавлением чеснока",
    image: "https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=500&q=80"
  },
  {
    name: "Красный соус",
    category: "Хлеб & Соусы",
    price: 150,
    unit: "шт",
    description: "Фирменный красный соус с добавлением томата и кинзы",
    image: "https://images.unsplash.com/photo-1598378854775-c90ab9fc0e77?w=500&q=80"
  },

  // ГОРЯЧИЕ БЛЮДА
  {
    name: "Хинкали",
    category: "Горячие блюда",
    price: 150,
    unit: "шт",
    description: "Варёные свино-говяжьи хинкали",
    image: "https://images.unsplash.com/photo-1626200339310-ff27f88a0af6?w=500&q=80"
  },
  {
    name: "Хачапури",
    category: "Горячие блюда",
    price: 350,
    unit: "шт",
    description: "Традиционный грузинский хачапури с сыром",
    image: "https://images.unsplash.com/photo-1601050690117-94f5f6fa9e50?w=500&q=80"
  }
];

const sampleReviews = [
  {
    author: "Алексей М.",
    rating: 5,
    text: "Отличное место! Мясо просто тает во рту. Особенно понравились бараньи рёбра - невероятно вкусные!",
    date: "2026-02-28"
  },
  {
    author: "Мария К.",
    rating: 5,
    text: "Лучший шашлык в городе! Всегда свежее мясо, приятная атмосфера. Рекомендую всем!",
    date: "2026-02-25"
  },
  {
    author: "Дмитрий П.",
    rating: 5,
    text: "Заказывали на компанию - все остались довольны. Порции большие, цены адекватные.",
    date: "2026-02-20"
  },
  {
    author: "Елена С.",
    rating: 4,
    text: "Очень вкусно готовят! Единственное - иногда приходится ждать, но оно того стоит.",
    date: "2026-02-15"
  },
  {
    author: "Игорь В.",
    rating: 5,
    text: "Семейное место с душой. Мясо маринуют отлично, прямо чувствуется качество!",
    date: "2026-02-10"
  }
];

export async function seedDatabase() {
  console.log("Seeding database...");

  // Clear existing data
  await db.orderItem.deleteMany();
  await db.order.deleteMany();
  await db.booking.deleteMany();
  await db.review.deleteMany();
  await db.menuItem.deleteMany();

  // Seed menu items
  for (const item of menuItems) {
    await db.menuItem.create({
      data: item
    });
  }

  // Seed reviews
  for (const review of sampleReviews) {
    await db.review.create({
      data: review
    });
  }

  console.log(`Seeded ${menuItems.length} menu items and ${sampleReviews.length} reviews`);
}
