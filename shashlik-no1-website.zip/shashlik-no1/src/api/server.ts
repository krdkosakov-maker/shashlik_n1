import { Hono } from "hono";
import { deserialize, serialize } from "superjson";
import { handleRpc } from "typed-rpc/server";
import { serve } from "@hono/node-server";
import {
  initializeServerEnvironment,
  runWithContext,
} from "@adaptive-ai/sdk/server";
import { startWorker, getActiveJobCount, getPendingJobCount } from "@/api/queue";
import { logError } from "@/api/errors";
import { env } from "@/lib/env";
import { inspect } from "util";

process.on("uncaughtException", (error) => {
  logError({
    source: "server",
    message: error.message,
    stack: error.stack,
    metadata: { type: "uncaughtException" },
  });
  console.error("Uncaught exception:", error);
});

process.on("unhandledRejection", (reason) => {
  logError({
    source: "server",
    message: reason instanceof Error ? reason.message : String(reason),
    stack: reason instanceof Error ? reason.stack : undefined,
    metadata: { type: "unhandledRejection" },
  });
  console.error("Unhandled rejection:", reason);
});

const transcoder = { serialize, deserialize };

initializeServerEnvironment({
  baseUrl: env.VITE_BASE_URL,
  realtimeDomain: env.VITE_REALTIME_DOMAIN,
  guestServicesUrl: env.GUEST_SERVICES_URL,
});

// Import procedures after initializing the environment
const { procedures } = await import("@/api");

const app = new Hono();

app.use("*", async (c, next) => {
  const start = Date.now();
  await next();
  const ms = Date.now() - start;
  const requestId = c.req.header("x-request-id");
  if (requestId) {
    console.log(`[${requestId}] ${c.req.method} ${c.req.url} - ${ms}ms`);
  } else {
    console.log(`${c.req.method} ${c.req.url} - ${ms}ms`);
  }
});

// This is called by the SDK
app.post("/_logger", async (c) => {
  const text = await c.req.text();
  const requestId = c.req.header("x-request-id");

  let message = text;
  let stack: string | undefined;
  let metadata: object | undefined;

  try {
    const body = JSON.parse(text);
    message = body.message ?? text;
    stack = body.stack;
    metadata = body.metadata;
  } catch {
    // Not JSON, use raw text as message
  }

  // Only keep warn and error messages
  if (message.startsWith("[console.warn]") || message.startsWith("[console.error]")) {
    logError({
      source: "client",
      message,
      stack,
      metadata,
      requestId: requestId ?? undefined,
    });
  }

  console.log("[browser]", message);

  return c.json({ status: "ok" });
});

app.get("/_queue/status", (c) => {
  const activeJobs = getActiveJobCount();
  const pendingJobs = getPendingJobCount();

  return c.json({ activeJobs, pendingJobs });
});

app.post("/api/*", async (c) => {
  const body = await c.req.json();

  const requestId = c.req.header("x-request-id");
  const channelId = c.req.header("x-channel-id");

  if (!requestId) {
    console.warn(
      "Request is missing x-request-id header. Adaptive AI SDK relies on this for request context.",
    );
  }

  console.log(`[${requestId}] Starting request ${c.req.method} ${c.req.url}`);

  if (channelId) {
    console.log(`[${requestId}] Channel ID: ${channelId}`);
  }

  // Create the request context
  const context = {
    requestId: requestId ?? "unknown-request-id",
    channelId,
    hasTasks: false,
  };

  // Run the rest of the request handling within the async context
  const result = await runWithContext(context, async () => {
    return await handleRpc(body, procedures, { transcoder });
  });

  console.log(
    `[${requestId}] Response:`,
    inspect(result, { depth: 3, colors: true }),
  );

  // Log RPC errors to error database
  // typed-rpc returns { json: { error: ... } } structure
  const rpcResult = result as { 
    json?: { 
      error?: { 
        message?: string; 
        stack?: string; 
        data?: unknown;
      } 
    } 
  };
  if (rpcResult.json?.error) {
    logError({
      source: "server",
      message: rpcResult.json.error.message ?? "Unknown RPC error",
      stack: rpcResult.json.error.stack,
      requestId: requestId ?? undefined,
      metadata: rpcResult.json.error.data ? { errorData: rpcResult.json.error.data } : undefined,
    });
  }

  return c.json(result);
});

serve({
  fetch: app.fetch,
  port: Number(env.PORT) + 1,
});

try {
  startWorker();
  console.log("Queue worker started successfully");
} catch (error) {
  console.error("Failed to start queue worker:", error);
}
