import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { client } from "@/lib/client";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { ShoppingCart, Plus, Minus, Trash2, CheckCircle2, Flame, Clock } from "lucide-react";

interface MenuItem {
  id: string;
  name: string;
  category: string;
  price: number;
  unit: string;
  description: string;
  image: string | null;
}

interface CartItem extends MenuItem {
  quantity: number;
}

interface OrderFormProps {
  menuItems: MenuItem[];
}

export default function OrderForm({ menuItems }: OrderFormProps) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    pickupTime: "",
    comment: ""
  });
  const [success, setSuccess] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const categories = Array.from(new Set(menuItems.map(item => item.category)));
  const filteredItems = selectedCategory
    ? menuItems.filter(item => item.category === selectedCategory)
    : menuItems;

  const addToCart = (item: MenuItem) => {
    const existing = cart.find(i => i.id === item.id);
    if (existing) {
      setCart(cart.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i));
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(cart.map(item => {
      if (item.id === id) {
        const newQuantity = item.quantity + delta;
        return newQuantity > 0 ? { ...item, quantity: newQuantity } : item;
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const orderMutation = useMutation({
    mutationFn: (data: typeof formData & { items: Array<{ menuItemId: string; quantity: number; price: number }> }) => 
      client.createOrder(data),
    onSuccess: () => {
      setSuccess(true);
      setCart([]);
      setFormData({
        name: "",
        phone: "",
        email: "",
        address: "",
        pickupTime: "",
        comment: ""
      });
      setShowCart(false);
      setTimeout(() => setSuccess(false), 5000);
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;
    
    orderMutation.mutate({
      ...formData,
      items: cart.map(item => ({
        menuItemId: item.id,
        quantity: item.quantity,
        price: item.price
      }))
    });
  };

  return (
    <div className="container mx-auto px-4">
      <div className="text-center mb-12">
        <div className="flex justify-center mb-4">
          <ShoppingCart className="h-12 w-12 text-orange-500" />
        </div>
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Заказ на вынос</h2>
        <p className="text-zinc-400 text-lg">Выберите блюда и оформите заказ на самовывоз</p>
      </div>

      {success && (
        <div className="mb-6 p-4 bg-green-900/20 border border-green-500/30 rounded-lg flex items-center gap-3 text-green-400 max-w-4xl mx-auto">
          <CheckCircle2 className="h-5 w-5" />
          <p>Заказ успешно оформлен! Мы свяжемся с вами для подтверждения.</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Menu Selection */}
        <div className="lg:col-span-2 space-y-6">
          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              variant={selectedCategory === null ? "default" : "outline"}
              className={selectedCategory === null 
                ? "bg-orange-600 hover:bg-orange-700" 
                : "border-orange-500/30 text-zinc-300 hover:bg-orange-500/10"}
              onClick={() => setSelectedCategory(null)}
            >
              Все
            </Button>
            {categories.map(category => (
              <Button
                key={category}
                size="sm"
                variant={selectedCategory === category ? "default" : "outline"}
                className={selectedCategory === category 
                  ? "bg-orange-600 hover:bg-orange-700" 
                  : "border-orange-500/30 text-zinc-300 hover:bg-orange-500/10"}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>

          {/* Menu Items */}
          <div className="space-y-3">
            {filteredItems.map(item => (
              <Card key={item.id} className="bg-zinc-900/50 border-orange-900/20 hover:border-orange-500/50 transition-all">
                <CardContent className="p-4 flex items-center gap-4">
                  <img 
                    src={item.image || "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=100&q=80"} 
                    alt={item.name}
                    className="w-20 h-20 object-cover rounded"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-white truncate">{item.name}</h4>
                    <p className="text-sm text-zinc-400 truncate">{item.description}</p>
                    <div className="text-orange-500 font-bold mt-1">{item.price}₽ / {item.unit}</div>
                  </div>
                  <Button
                    size="sm"
                    className="bg-orange-600 hover:bg-orange-700 shrink-0"
                    onClick={() => addToCart(item)}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Cart & Checkout */}
        <div className="lg:col-span-1">
          <Card className="bg-zinc-900/50 border-orange-900/20 sticky top-20">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  Корзина ({cart.length})
                </span>
                <span className="text-orange-500">{total}₽</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {cart.length === 0 ? (
                <p className="text-zinc-400 text-center py-8">Корзина пуста</p>
              ) : (
                <>
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {cart.map(item => (
                      <div key={item.id} className="flex items-center gap-2 bg-zinc-800/50 rounded p-2">
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-white truncate">{item.name}</div>
                          <div className="text-xs text-orange-500">{item.price}₽ × {item.quantity}</div>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-6 w-6 text-zinc-400 hover:text-white"
                            onClick={() => updateQuantity(item.id, -1)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="text-white w-6 text-center">{item.quantity}</span>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-6 w-6 text-zinc-400 hover:text-white"
                            onClick={() => updateQuantity(item.id, 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-6 w-6 text-red-400 hover:text-red-300"
                            onClick={() => removeFromCart(item.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Button
                    className="w-full bg-orange-600 hover:bg-orange-700"
                    onClick={() => setShowCart(true)}
                    disabled={cart.length === 0}
                  >
                    Оформить заказ
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Checkout Modal */}
      {showCart && cart.length > 0 && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50" onClick={() => setShowCart(false)}>
          <Card className="bg-zinc-900 border-orange-900/20 max-w-2xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Flame className="h-6 w-6 text-orange-500" />
                Оформление заказа
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="order-name" className="text-zinc-200">Ваше имя *</Label>
                    <Input
                      id="order-name"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="bg-zinc-800 border-zinc-700 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="order-phone" className="text-zinc-200">Телефон *</Label>
                    <Input
                      id="order-phone"
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="bg-zinc-800 border-zinc-700 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="order-email" className="text-zinc-200">Email</Label>
                    <Input
                      id="order-email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="bg-zinc-800 border-zinc-700 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="pickup-time" className="text-zinc-200 flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Время самовывоза
                    </Label>
                    <Input
                      id="pickup-time"
                      type="time"
                      value={formData.pickupTime}
                      onChange={(e) => setFormData({ ...formData, pickupTime: e.target.value })}
                      className="bg-zinc-800 border-zinc-700 text-white"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="order-comment" className="text-zinc-200">Комментарий</Label>
                  <Textarea
                    id="order-comment"
                    value={formData.comment}
                    onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                    className="bg-zinc-800 border-zinc-700 text-white"
                    rows={3}
                  />
                </div>

                <div className="border-t border-orange-900/20 pt-4">
                  <div className="flex justify-between text-lg font-semibold text-white mb-4">
                    <span>Итого:</span>
                    <span className="text-orange-500">{total}₽</span>
                  </div>
                  <div className="flex gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      className="flex-1 border-zinc-700 text-zinc-300"
                      onClick={() => setShowCart(false)}
                    >
                      Отмена
                    </Button>
                    <Button
                      type="submit"
                      className="flex-1 bg-orange-600 hover:bg-orange-700"
                      disabled={orderMutation.isPending}
                    >
                      {orderMutation.isPending ? "Отправка..." : "Подтвердить заказ"}
                    </Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
