import { MapPin, Phone, Clock, MessageCircle } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";

export default function Contact() {
  return (
    <div className="container mx-auto px-4">
      <div className="text-center mb-12">
        <div className="flex justify-center mb-4">
          <MapPin className="h-12 w-12 text-orange-500" />
        </div>
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Контакты</h2>
        <p className="text-zinc-400 text-lg">Приходите к нам и насладитесь настоящим вкусом</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
        {/* Contact Info */}
        <div className="space-y-6">
          <Card className="bg-zinc-900/50 border-orange-900/20">
            <CardContent className="p-6 space-y-6">
              <div className="flex items-start gap-4">
                <MapPin className="h-6 w-6 text-orange-500 shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-white mb-2">Адрес</h3>
                  <p className="text-zinc-300">Краснодар, улица Автолюбителей, 1/2Я</p>
                  <a 
                    href="https://yandex.ru/maps/-/CPqryHJC" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-orange-500 hover:text-orange-400 text-sm mt-2 inline-block"
                  >
                    Открыть на карте →
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="h-6 w-6 text-orange-500 shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-white mb-2">Телефон</h3>
                  <a href="tel:+7XXXXXXXXXX" className="text-zinc-300 hover:text-orange-500 transition-colors">
                    +7 (XXX) XXX-XX-XX
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Clock className="h-6 w-6 text-orange-500 shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-white mb-2">Режим работы</h3>
                  <div className="text-zinc-300 space-y-1">
                    <p>Понедельник - Воскресенье</p>
                    <p className="text-orange-500 font-semibold">10:00 - 23:00</p>
                  </div>
                </div>
              </div>

              <div className="border-t border-orange-900/20 pt-6">
                <h3 className="font-semibold text-white mb-4">Свяжитесь с нами</h3>
                <div className="flex gap-3">
                  <Button
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    onClick={() => window.open('https://wa.me/7XXXXXXXXXX', '_blank')}
                  >
                    <MessageCircle className="h-5 w-5 mr-2" />
                    WhatsApp
                  </Button>
                  <Button
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                    onClick={() => window.open('https://t.me/XXXXXXXX', '_blank')}
                  >
                    <MessageCircle className="h-5 w-5 mr-2" />
                    Telegram
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-zinc-900/50 border-orange-900/20">
            <CardContent className="p-6">
              <h3 className="font-semibold text-white mb-4">О ресторане</h3>
              <div className="text-zinc-300 space-y-3 text-sm leading-relaxed">
                <p>
                  <span className="text-orange-500 font-semibold">Шашлычная №1</span> - это место, где традиции кавказской кухни 
                  встречаются с современным подходом к обслуживанию.
                </p>
                <p>
                  Мы используем только свежее мясо высшего качества, которое маринуем по авторским рецептам 
                  и готовим на настоящем мангале с живым огнем.
                </p>
                <p>
                  У нас вы найдете широкий выбор шашлыков, люля-кебабов, домашних хинкали и других блюд 
                  грузинской и кавказской кухни.
                </p>
                <p className="text-orange-500 font-semibold">
                  Средний чек: от 800₽
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Map */}
        <div className="h-[600px] rounded-lg overflow-hidden border border-orange-900/20">
          <iframe
            src="https://yandex.ru/map-widget/v1/?ll=39.070092%2C44.995733&mode=search&oid=236073727318&ol=biz&z=16"
            width="100%"
            height="100%"
            frameBorder="0"
            allowFullScreen
            className="w-full h-full"
          ></iframe>
        </div>
      </div>
    </div>
  );
}
