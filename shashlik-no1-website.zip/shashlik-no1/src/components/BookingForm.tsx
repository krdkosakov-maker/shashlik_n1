import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { client } from "@/lib/client";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Calendar, Clock, Users, CheckCircle2, Flame } from "lucide-react";

export default function BookingForm() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    date: "",
    time: "",
    guests: 2,
    comment: ""
  });
  const [success, setSuccess] = useState(false);

  const bookingMutation = useMutation({
    mutationFn: (data: typeof formData) => client.createBooking(data),
    onSuccess: () => {
      setSuccess(true);
      setFormData({
        name: "",
        phone: "",
        email: "",
        date: "",
        time: "",
        guests: 2,
        comment: ""
      });
      setTimeout(() => setSuccess(false), 5000);
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    bookingMutation.mutate(formData);
  };

  return (
    <div className="container mx-auto px-4">
      <div className="text-center mb-12">
        <div className="flex justify-center mb-4">
          <Calendar className="h-12 w-12 text-orange-500" />
        </div>
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Бронирование столика</h2>
        <p className="text-zinc-400 text-lg">Забронируйте стол и насладитесь атмосферой настоящего кавказского гостеприимства</p>
      </div>

      <div className="max-w-2xl mx-auto">
        {success && (
          <div className="mb-6 p-4 bg-green-900/20 border border-green-500/30 rounded-lg flex items-center gap-3 text-green-400">
            <CheckCircle2 className="h-5 w-5" />
            <p>Бронирование успешно отправлено! Мы свяжемся с вами в ближайшее время.</p>
          </div>
        )}

        <Card className="bg-zinc-900/50 border-orange-900/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Flame className="h-6 w-6 text-orange-500" />
              Форма бронирования
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-zinc-200">Ваше имя *</Label>
                  <Input
                    id="name"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-zinc-800 border-zinc-700 text-white"
                    placeholder="Иван Иванов"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-zinc-200">Телефон *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="bg-zinc-800 border-zinc-700 text-white"
                    placeholder="+7 (XXX) XXX-XX-XX"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-zinc-200">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="bg-zinc-800 border-zinc-700 text-white"
                    placeholder="email@example.com"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="guests" className="text-zinc-200 flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Количество гостей *
                  </Label>
                  <Input
                    id="guests"
                    type="number"
                    min="1"
                    max="50"
                    required
                    value={formData.guests}
                    onChange={(e) => setFormData({ ...formData, guests: parseInt(e.target.value) })}
                    className="bg-zinc-800 border-zinc-700 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="date" className="text-zinc-200 flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    Дата *
                  </Label>
                  <Input
                    id="date"
                    type="date"
                    required
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="bg-zinc-800 border-zinc-700 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="time" className="text-zinc-200 flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Время *
                  </Label>
                  <Input
                    id="time"
                    type="time"
                    required
                    value={formData.time}
                    onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                    className="bg-zinc-800 border-zinc-700 text-white"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="comment" className="text-zinc-200">Комментарий</Label>
                <Textarea
                  id="comment"
                  value={formData.comment}
                  onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                  className="bg-zinc-800 border-zinc-700 text-white"
                  placeholder="Особые пожелания, аллергии, предпочтения по размещению..."
                  rows={4}
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-orange-600 hover:bg-orange-700 text-white py-6 text-lg"
                disabled={bookingMutation.isPending}
              >
                {bookingMutation.isPending ? "Отправка..." : "Забронировать стол"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
