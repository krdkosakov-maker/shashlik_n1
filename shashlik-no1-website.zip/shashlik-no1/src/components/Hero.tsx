import { Flame, Star, Clock, MapPin } from "lucide-react";
import { Button } from "./ui/button";

export default function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-orange-950/30 via-zinc-900/50 to-zinc-950"></div>
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `url("https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=1920&q=80")`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            filter: "grayscale(0.3)",
          }}
        ></div>
        {/* Fire particles animation */}
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full bg-orange-500/30 animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                width: `${Math.random() * 10 + 5}px`,
                height: `${Math.random() * 10 + 5}px`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${Math.random() * 10 + 10}s`,
              }}
            ></div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center mt-16">
        <div className="flex justify-center mb-6">
          <Flame className="h-20 w-20 text-orange-500 animate-pulse" />
        </div>
        
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 animate-fade-in">
          ШАШЛЫЧНАЯ <span className="text-orange-500">№1</span>
        </h1>
        
        <p className="text-xl md:text-2xl text-zinc-300 mb-8 animate-fade-in-delay">
          Настоящий вкус мяса на огне
        </p>

        <div className="flex flex-wrap justify-center gap-6 mb-12 text-zinc-200">
          <div className="flex items-center gap-2">
            <Star className="h-5 w-5 text-orange-500 fill-orange-500" />
            <span className="font-semibold">5.0</span>
            <span className="text-zinc-400">(833 отзыва)</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-orange-500" />
            <span>Работаем до 23:00</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-orange-500" />
            <span>ул. Автолюбителей, 1/2Я</span>
          </div>
        </div>

        <div className="flex flex-wrap justify-center gap-4">
          <Button
            size="lg"
            className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-6 text-lg"
            onClick={() => scrollToSection("menu")}
          >
            Посмотреть меню
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-orange-500 text-orange-500 hover:bg-orange-500/10 px-8 py-6 text-lg"
            onClick={() => scrollToSection("booking")}
          >
            Забронировать стол
          </Button>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20 max-w-4xl mx-auto">
          <div className="bg-zinc-900/50 backdrop-blur-sm border border-orange-900/20 rounded-lg p-6">
            <Flame className="h-10 w-10 text-orange-500 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-white mb-2">Свежее мясо</h3>
            <p className="text-zinc-400 text-sm">Только качественное мясо, ежедневная поставка</p>
          </div>
          <div className="bg-zinc-900/50 backdrop-blur-sm border border-orange-900/20 rounded-lg p-6">
            <Flame className="h-10 w-10 text-orange-500 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-white mb-2">На мангале</h3>
            <p className="text-zinc-400 text-sm">Приготовление на живом огне, как полагается</p>
          </div>
          <div className="bg-zinc-900/50 backdrop-blur-sm border border-orange-900/20 rounded-lg p-6">
            <Flame className="h-10 w-10 text-orange-500 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-white mb-2">Банкеты</h3>
            <p className="text-zinc-400 text-sm">Проведение банкетов и мероприятий</p>
          </div>
        </div>
      </div>
    </div>
  );
}
