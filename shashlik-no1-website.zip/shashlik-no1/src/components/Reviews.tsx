import { useQuery } from "@tanstack/react-query";
import { client } from "@/lib/client";
import { Card, CardContent } from "./ui/card";
import { Star, MessageSquare } from "lucide-react";

export default function Reviews() {
  const { data: reviews = [] } = useQuery({
    queryKey: ["reviews"],
    queryFn: () => client.getReviews()
  });

  return (
    <div className="container mx-auto px-4">
      <div className="text-center mb-12">
        <div className="flex justify-center mb-4">
          <MessageSquare className="h-12 w-12 text-orange-500" />
        </div>
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Отзывы наших гостей</h2>
        <p className="text-zinc-400 text-lg">Что говорят о нас наши клиенты</p>
        
        <div className="flex items-center justify-center gap-2 mt-6">
          <div className="flex">
            {[1, 2, 3, 4, 5].map(star => (
              <Star key={star} className="h-6 w-6 text-orange-500 fill-orange-500" />
            ))}
          </div>
          <span className="text-2xl font-bold text-white">5.0</span>
          <span className="text-zinc-400">(833 отзыва на Яндекс.Картах)</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {reviews.map(review => (
          <Card key={review.id} className="bg-zinc-900/50 border-orange-900/20 hover:border-orange-500/50 transition-all">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-white">{review.author}</h4>
                <div className="flex">
                  {Array.from({ length: review.rating }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-orange-500 fill-orange-500" />
                  ))}
                </div>
              </div>
              <p className="text-zinc-300 text-sm leading-relaxed mb-3">{review.text}</p>
              <p className="text-xs text-zinc-500">{new Date(review.date).toLocaleDateString('ru-RU')}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="text-center mt-12">
        <p className="text-zinc-400 mb-4">Хотите оставить отзыв?</p>
        <a 
          href="https://yandex.ru/maps/-/CPqryHJC" 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-block px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-medium transition-colors"
        >
          Оставить отзыв на Яндекс.Картах
        </a>
      </div>
    </div>
  );
}
