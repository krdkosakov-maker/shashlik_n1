import { useState, useEffect, useCallback } from "react";
import { Camera, X, ChevronLeft, ChevronRight } from "lucide-react";

interface GalleryImage {
  url: string;
  category: string;
  title: string;
}

const galleryImages: GalleryImage[] = [
  {
    url: "https://avatars.mds.yandex.net/get-sprav-products/3911103/2a00000193bc30c90e2ed0cee48f182533af/orig",
    category: "food",
    title: "Свиная шея"
  },
  {
    url: "https://avatars.mds.yandex.net/get-sprav-products/1540730/2a00000193bc361bb7af97351cab0441ff62/orig",
    category: "food",
    title: "Свиная мякоть"
  },
  {
    url: "https://avatars.mds.yandex.net/get-sprav-products/1424222/2a00000193bc401006a720123ea04cdf786b/orig",
    category: "food",
    title: "Свиные рёбра"
  },
  {
    url: "https://avatars.mds.yandex.net/get-sprav-products/2791887/2a00000193bc41d35f07045f897dcb1efa7c/orig",
    category: "food",
    title: "Антрекот свиной"
  },
  {
    url: "https://avatars.mds.yandex.net/get-sprav-products/1530321/2a00000193bc483bf5db0519c38f0a833ee8/orig",
    category: "food",
    title: "Бараньи рёбра"
  },
  {
    url: "https://avatars.mds.yandex.net/get-altay/13996387/2a00000193b6622c6be5392abff8d1773ac6/XXXL",
    category: "food",
    title: "Шашлык на мангале"
  },
  {
    url: "https://avatars.mds.yandex.net/get-altay/13474366/2a00000193b662222eba5a7326e347c6a660/XXXL",
    category: "food",
    title: "Мясо на гриле"
  },
  {
    url: "https://avatars.mds.yandex.net/get-altay/14540779/2a00000193b6621198138cafaefc64428ca0/XXXL",
    category: "food",
    title: "Ассорти шашлыков"
  },
  {
    url: "https://avatars.mds.yandex.net/get-altay/13996387/2a00000193b661f7ef729301076ffb503f97/XXXL",
    category: "food",
    title: "Свежее мясо"
  },
  {
    url: "https://avatars.mds.yandex.net/get-altay/13793720/2a000001928478c5d8d3e5c2458573ad6b3c/XXXL",
    category: "food",
    title: "Гриль блюда"
  },
  {
    url: "https://avatars.mds.yandex.net/get-altay/13590061/2a00000191f183eb1f3bc017357d69cdb64f/XXXL",
    category: "food",
    title: "Шашлык"
  }
];

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const openLightbox = (index: number) => {
    setSelectedImage(index);
    document.body.style.overflow = "hidden";
  };

  const closeLightbox = useCallback(() => {
    setSelectedImage(null);
    document.body.style.overflow = "auto";
  }, []);

  const goToPrevious = useCallback(() => {
    if (selectedImage !== null) {
      setSelectedImage((selectedImage - 1 + galleryImages.length) % galleryImages.length);
    }
  }, [selectedImage]);

  const goToNext = useCallback(() => {
    if (selectedImage !== null) {
      setSelectedImage((selectedImage + 1) % galleryImages.length);
    }
  }, [selectedImage]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedImage === null) return;
      
      if (e.key === "Escape") closeLightbox();
      if (e.key === "ArrowLeft") goToPrevious();
      if (e.key === "ArrowRight") goToNext();
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedImage, closeLightbox, goToPrevious, goToNext]);

  return (
    <div className="container mx-auto px-4">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Camera className="w-8 h-8 text-orange-500" />
          <h2 className="text-4xl md:text-5xl font-bold text-white">
            Галерея
          </h2>
        </div>
        <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
          Наши фирменные блюда — свежее мясо, приготовленное на открытом огне
        </p>
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
        {galleryImages.map((image, index) => (
          <div
            key={index}
            className="group relative aspect-square overflow-hidden rounded-xl bg-zinc-900 cursor-pointer"
            onClick={() => openLightbox(index)}
          >
            <img
              src={image.url}
              alt={image.title}
              loading="lazy"
              className="w-full h-full object-cover transition-all duration-500 group-hover:scale-110 group-hover:rotate-1"
            />
            
            {/* Overlay on hover */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <h3 className="text-white font-semibold text-lg">
                  {image.title}
                </h3>
              </div>
            </div>

            {/* Fire icon in corner */}
            <div className="absolute top-2 right-2 w-8 h-8 bg-orange-500/80 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <span className="text-white text-lg">🔥</span>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Modal */}
      {selectedImage !== null && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4"
          onClick={closeLightbox}
        >
          {/* Close button */}
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 z-50 w-12 h-12 bg-orange-500/20 hover:bg-orange-500/40 rounded-full flex items-center justify-center transition-colors"
            aria-label="Закрыть"
          >
            <X className="w-6 h-6 text-white" />
          </button>

          {/* Previous button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              goToPrevious();
            }}
            className="absolute left-4 z-50 w-12 h-12 bg-orange-500/20 hover:bg-orange-500/40 rounded-full flex items-center justify-center transition-colors"
            aria-label="Предыдущее"
          >
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>

          {/* Next button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              goToNext();
            }}
            className="absolute right-4 z-50 w-12 h-12 bg-orange-500/20 hover:bg-orange-500/40 rounded-full flex items-center justify-center transition-colors"
            aria-label="Следующее"
          >
            <ChevronRight className="w-6 h-6 text-white" />
          </button>

          {/* Image container */}
          <div
            className="relative max-w-6xl max-h-[90vh] w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={galleryImages[selectedImage].url}
              alt={galleryImages[selectedImage].title}
              className="w-full h-full object-contain rounded-lg"
            />
            
            {/* Image title */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6 rounded-b-lg">
              <h3 className="text-white text-2xl font-bold text-center">
                {galleryImages[selectedImage].title}
              </h3>
              <p className="text-zinc-300 text-center mt-1">
                {selectedImage + 1} / {galleryImages.length}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
