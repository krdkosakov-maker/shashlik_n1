import { useState } from "react";
import { Flame } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";

interface MenuItem {
  id: string;
  name: string;
  category: string;
  price: number;
  unit: string;
  description: string;
  image: string | null;
}

interface MenuProps {
  menuItems: MenuItem[];
}

export default function Menu({ menuItems }: MenuProps) {
  const categories = Array.from(new Set(menuItems.map(item => item.category)));
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredItems = selectedCategory
    ? menuItems.filter(item => item.category === selectedCategory)
    : menuItems;

  const groupedItems = filteredItems.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, MenuItem[]>);

  return (
    <div className="container mx-auto px-4">
      <div className="text-center mb-12">
        <div className="flex justify-center mb-4">
          <Flame className="h-12 w-12 text-orange-500" />
        </div>
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Наше меню</h2>
        <p className="text-zinc-400 text-lg">Только лучшее мясо, приготовленное на живом огне</p>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap justify-center gap-3 mb-12">
        <Button
          variant={selectedCategory === null ? "default" : "outline"}
          className={selectedCategory === null 
            ? "bg-orange-600 hover:bg-orange-700" 
            : "border-orange-500/30 text-zinc-300 hover:bg-orange-500/10"}
          onClick={() => setSelectedCategory(null)}
        >
          Все категории
        </Button>
        {categories.map(category => (
          <Button
            key={category}
            variant={selectedCategory === category ? "default" : "outline"}
            className={selectedCategory === category 
              ? "bg-orange-600 hover:bg-orange-700" 
              : "border-orange-500/30 text-zinc-300 hover:bg-orange-500/10"}
            onClick={() => setSelectedCategory(category)}
          >
            {category}
          </Button>
        ))}
      </div>

      {/* Menu Items by Category */}
      <div className="space-y-16">
        {Object.entries(groupedItems).map(([category, items]) => (
          <div key={category}>
            <h3 className="text-2xl md:text-3xl font-bold text-orange-500 mb-6 border-b border-orange-900/20 pb-3">
              {category}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {items.map(item => (
                <Card key={item.id} className="bg-zinc-900/50 border-orange-900/20 hover:border-orange-500/50 transition-all hover:shadow-lg hover:shadow-orange-500/10 overflow-hidden group">
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={item.image || "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=500&q=80"} 
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 to-transparent"></div>
                  </div>
                  <CardContent className="p-5">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="text-lg font-semibold text-white">{item.name}</h4>
                      <div className="text-right">
                        <div className="text-xl font-bold text-orange-500">{item.price}₽</div>
                        <div className="text-xs text-zinc-500">{item.unit}</div>
                      </div>
                    </div>
                    <p className="text-sm text-zinc-400 leading-relaxed">{item.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
